# Minimalist Recurring Task Builder & Team Verification Hub

A minimalist recurring task management and daily verification hub designed for teams and individuals. It automates daily checklist generation based on custom recurrence schedules (daily, specific weekdays, and designated weeks of the month), tracks check-offs, and provides weekly and monthly compliance reports.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Based on your clarifications, the following product architectural decisions are confirmed for implementation:

- **Confirmed Decision 1 (Dual View Architecture)**: The application will feature both an **Individual Member View** (with a quick member selector and personalized daily checklist) and a **Unified Team View** (showing team-wide task statuses and aggregated progress in a clean matrix).
- **Confirmed Decision 2 (Recurrence Frequency Engine)**: Supports three core recurrence tiers:
  1. *Daily Tasks*: Automatically populates every single day.
  2. *Specific Weekdays*: Populates on selected days (e.g. Monday, Tuesday, Friday).
  3. *Week of the Month*: Assigned to specific monthly cycles (e.g. Week 1 or Week 2 of the month, optionally combined with specific weekdays).
- **Confirmed Decision 3 (Task Setup & Builder)**: Ships with a preloaded 10-task enterprise template (5 daily tasks + 5 day/week-specific tasks across team members) ready to test immediately, along with an intuitive **Task Builder Modal** allowing users to create, edit, reassign, or adjust recurrence frequencies dynamically.
- **Reporting Architecture**: Built-in **Weekly Report** (day-by-day 7-day checklist compliance and member completion rates) and **Monthly Report** (week-by-week aggregated completion percentages, total checks completed, and task health audit).

---

## 1. Overview & Core Concept

### What It Does
The Minimalist Task Builder streamlines operational routines and recurring checklists. Instead of manually recreating to-do lists, users define their tasks and recurrence rules once. Every day, the system evaluates the calendar date and dynamically populates only the tasks due for that exact day. Team members or team leads check off items as they are verified. Checkbox states are timestamped and preserved historically, generating audit-ready weekly and monthly reports.

### Target Audience & Persona
- **Team Leads & Operations Managers**: Ensuring standard operating procedures, weekly audits, and daily operational routines are checked without fail.
- **Individual Contributors & Specialists**: Keeping track of personal daily duties alongside recurring Tuesday audits or 1st-week-of-month reconciliations.

### Key Value
- **Zero Checklist Clutter**: Only today's relevant tasks appear; Tuesday tasks don't distract on Monday, and Week 2 reconciliations don't clutter Week 1.
- **Automatic Day Rollover**: When the next day arrives (or when selecting any date via the day selector), the checklist automatically updates to reflect that day's schedule.
- **Accountability & Reporting**: Real-time progress bars, completion streaks, and weekly/monthly compliance summaries.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Daily Checklist & Check-Off Flow**:
   - The user lands on the dashboard showing today's date (with previous/next day navigation and a calendar jump picker).
   - Tasks due for the selected date are neatly grouped or filtered. Each task item displays the member name, task title, schedule tag (e.g., "Daily", "Every Tuesday", "Week 1 · Monday"), and an interactive checkbox.
   - Checking a task triggers a subtle visual completion transition (soft strikethrough, subtle badge highlight, instant progress counter update).
2. **Individual vs. Unified Team Toggle**:
   - A segmented view switcher (`Individual View` | `Team Board` | `Reports` | `Manage Tasks`).
   - In *Individual View*, users can switch between team members (or "My View") to focus solely on their personal checklist.
   - In *Team Board*, tasks are organized by member columns or rows with instant team completion ratios (`14/18 completed today`).
3. **Task Builder & Recurrence Configurator**:
   - Clean drawer/modal to add or edit tasks:
     - Task Title & Category/Department.
     - Assigned Team Member.
     - Recurrence Type:
       - **Daily**: Every day.
       - **Weekly / Days of Week**: Checkbox pills for Mon, Tue, Wed, Thu, Fri, Sat, Sun.
       - **Week of Month**: Week 1, Week 2, Week 3, Week 4, or Last Week (combined with specific weekdays, e.g. "Week 1 Monday").
4. **Weekly & Monthly Reports**:
   - **Weekly View**: 7-column matrix (Mon–Sun) showing completion status for every scheduled task, compliance percentage per team member, and missed tasks.
   - **Monthly View**: Calendar month overview with weekly completion trends, total volume of checks performed, top recurring task compliance, and a one-click printable / exportable summary.

### Visual Identity & Theme
- **Aesthetic Direction**: Minimalist, utilitarian workspace inspired by Linear and high-end Swiss editorial software. Zero unnecessary shadows, zero fake cockpit scores, zero neon fluff.
- **Color Palette**:
  - Neutral Canvas: Crisp white (`#ffffff`) and calm off-white / light neutral slate (`#f8fafc`).
  - Structural Surfaces & Borders: Subtle hairline borders (`#e2e8f0` / `border-slate-200`) and soft zinc surfaces (`#f1f5f9`).
  - Typography: Dark charcoal (`#0f172a` / `text-slate-900`) for primary headers and `#64748b` (`text-slate-500`) for secondary metadata.
  - Accent / Positive State: Focused emerald (`#059669` / `text-emerald-700`, `#ecfdf5` background) for verified checks.
- **Typography & Hierarchy**:
  - Primary Display & Headings: `Plus Jakarta Sans` / modern geometric sans.
  - Body Prose & Lists: `DM Sans` / clean humanist sans.
  - Metrics, Dates & Counters: `font-mono tabular-nums` for precise alignment of completion statistics (e.g. `05/10`, `100%`).
- **Zero-Pill Metadata**:
  - Information like recurrence tags and member roles are rendered as clean, unboxed text with typographic separators (`·` or `/`), reserving bordered pills strictly for interactive filter buttons.

---

## 3. Key Product Decisions & Trade-Offs

- **Deterministic Recurrence Evaluation**:
  - *Chosen Approach*: Recurrence rules are evaluated on the fly against any target date via a deterministic algorithm calculating the day of the week (0–6) and calendar week of the month (1st–5th occurrence of that weekday).
  - *Why*: Allows instantaneous navigation to yesterday, tomorrow, next week, or any month without generating thousands of static database rows in advance.
- **Historical Completion Logging**:
  - *Chosen Approach*: Check completions are stored in a key-value record keyed by `dateStr:taskId` (e.g., `2026-10-16:task-3`), storing boolean status, completion timestamp, and notes.
  - *Why*: Ensures past logs remain intact even if today's tasks change, and enables accurate weekly/monthly reporting across all historical days.
- **State Persistence**:
  - *Chosen Approach*: Reactive local storage state with versioned fallback defaults.
  - *Why*: Immediate zero-latency startup in the browser with no sign-in barriers, while maintaining complete offline persistence and a "Reset to Demo Template" option.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Minimalist Task Hub App                         │
├────────────────────────────────────────────────────────────────────────┤
│ Top Bar: Brand Wordmark ── Navigation Tabs ── Quick Actions            │
├────────────────────────────────────────────────────────────────────────┤
│ Date Navigation Bar: [ < ] Today: Tuesday, Oct 14, 2026 [ > ] [Calendar]│
│ Metrics Bar: [ Today's Progress: 8/10 (80%) ] [ Active Members: 4 ]     │
├──────────────────────────────────────────┬─────────────────────────────┤
│ Primary Content View                     │ Secondary / Modal Controls  │
│                                          │                             │
│ ┌──────────────────────────────────────┐ │ ┌─────────────────────────┐ │
│ │ Mode: Individual View                │ │ │ Task Builder Modal      │ │
│ │  - Member Switcher (Alex, Sarah...)  │ │ │  - Title, Assignee      │ │
│ │  - Daily Checklist Table/List        │ │ │  - Recurrence Picker    │ │
│ │  - Checkbox + Time Stamp             │ │ │    (Daily/Weekday/WkMo) │ │
│ └──────────────────────────────────────┘ │ └─────────────────────────┘ │
│ ┌──────────────────────────────────────┐ │ ┌─────────────────────────┐ │
│ │ Mode: Team Board                     │ │ │ Report Generator Modal  │ │
│ │  - Member Grid / Cards               │ │ │  - Weekly Compliance    │ │
│ │  - Status by Assignee                │ │ │  - Monthly Audit Sheet  │ │
│ └──────────────────────────────────────┘ │ └─────────────────────────┘ │
│ ┌──────────────────────────────────────┐ │                             │
│ │ Mode: Weekly & Monthly Reports       │ │                             │
│ │  - 7-Day Matrix Table                │ │                             │
│ │  - Monthly Fulfillment Summary       │ │                             │
│ └──────────────────────────────────────┘ │                             │
├──────────────────────────────────────────┴─────────────────────────────┤
│ Recurrence Engine: isTaskDueOnDate(task, date)                         │
│ Local Storage Store: Tasks[] + Members[] + CompletionsMap              │
└────────────────────────────────────────────────────────────────────────┘
```

### Core Data Models

```typescript
export type RecurrenceType = 'daily' | 'weekdays' | 'month_week';

export interface RecurrenceRule {
  type: RecurrenceType;
  // For 'weekdays': [1, 2, 3, 4, 5] (1=Mon, 2=Tue, etc.)
  daysOfWeek?: number[];
  // For 'month_week': week of month (1, 2, 3, 4, 5) + days of week
  weekOfMonth?: number; // 1 = 1st week, 2 = 2nd week, etc.
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  assigneeId: string;
  category: string;
  recurrence: RecurrenceRule;
  createdAt: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  avatarColor: string;
}

export interface TaskCompletionRecord {
  taskId: string;
  date: string; // YYYY-MM-DD
  completed: boolean;
  completedAt?: string;
  completedBy?: string;
}
```

### Preloaded Template (10 Standard Tasks)
1. *Daily Standup & Production Log* (Daily - Alex)
2. *System Health & Database Heartbeat* (Daily - Alex)
3. *Customer Inbox Zero Check* (Daily - Sarah)
4. *Inventory & Order Dispatch Verification* (Daily - Marcus)
5. *Daily Cash & Ledger Reconciliation* (Daily - Elena)
6. *Monday Weekly Planning & Sprint Kickoff* (Mondays - Alex)
7. *Tuesday Vendor Invoice & Billing Audit* (Tuesdays - Elena)
8. *Wednesday Client Feedback & SLA Review* (Wednesdays - Sarah)
9. *Thursday Operations & Security Patching* (Thursdays - Marcus)
10. *Week 1 Monthly Financial Close* (Week 1 of month, Monday - Elena)
*(Users can modify, delete, or add as many custom tasks as desired).*
