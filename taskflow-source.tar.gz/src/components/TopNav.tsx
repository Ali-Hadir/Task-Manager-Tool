import React from 'react';
import { useTasks } from '../context/TaskContext';
import { ViewMode } from '../types';
import { Plus, CheckSquare, RotateCcw } from 'lucide-react';

export const TopNav: React.FC = () => {
  const { viewMode, setViewMode, setIsTaskModalOpen, setEditingTask, resetToDemo } = useTasks();

  const navItems: { mode: ViewMode; label: string }[] = [
    { mode: 'individual', label: 'Daily Checklist' },
    { mode: 'team', label: 'Team Board' },
    { mode: 'reports', label: 'Reports & Audits' },
    { mode: 'manage', label: 'Task Schedules' },
  ];

  const handleOpenNewTask = () => {
    setEditingTask(null);
    setIsTaskModalOpen(true);
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-sm">
              <CheckSquare className="w-4 h-4" />
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
              TaskFlow
            </span>
          </div>

          {/* Zone 2: Single-line navigation links/tabs */}
          <nav className="flex items-center gap-1 sm:gap-2">
            {navItems.map((item) => {
              const isActive = viewMode === item.mode;
              return (
                <button
                  key={item.mode}
                  onClick={() => setViewMode(item.mode)}
                  className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-slate-100 text-slate-900 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary action button + quick reset */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={resetToDemo}
              title="Reset to 10-Task Demo Template"
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={handleOpenNewTask}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shadow-sm cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Task</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
