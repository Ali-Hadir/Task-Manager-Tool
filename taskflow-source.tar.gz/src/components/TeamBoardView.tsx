import React from 'react';
import { useTasks } from '../context/TaskContext';
import { TaskItem } from './TaskItem';
import { formatDisplayDate } from '../utils/dateUtils';
import { Users, CheckCircle, Plus } from 'lucide-react';

export const TeamBoardView: React.FC = () => {
  const {
    members,
    selectedDate,
    getDueTasksForDate,
    isTaskCompleted,
    markAllForDate,
    setEditingTask,
    setIsTaskModalOpen,
  } = useTasks();

  const handleEdit = (task: any) => {
    setEditingTask(task);
    setIsTaskModalOpen(true);
  };

  const allDueTasksToday = getDueTasksForDate(selectedDate);
  const totalCompleted = allDueTasksToday.filter((t) => isTaskCompleted(t.id, selectedDate)).length;
  const overallPercentage =
    allDueTasksToday.length > 0
      ? Math.round((totalCompleted / allDueTasksToday.length) * 100)
      : 0;

  return (
    <div className="space-y-6">
      {/* Team Summary Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-500" />
            <h2 className="text-sm font-bold text-slate-900 tracking-tight">
              Team Execution Board · {formatDisplayDate(selectedDate)}
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time verification grid across all {members.length} team members for this date.
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <span className="text-xs text-slate-500">Overall Team Compliance</span>
            <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
              {totalCompleted} / {allDueTasksToday.length}{' '}
              <span className="text-xs font-normal text-slate-500">({overallPercentage}%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Member Columns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
        {members.map((member) => {
          const memberTasks = getDueTasksForDate(selectedDate, member.id);
          const completedCount = memberTasks.filter((t) =>
            isTaskCompleted(t.id, selectedDate)
          ).length;
          const totalTasks = memberTasks.length;
          const isComplete = totalTasks > 0 && completedCount === totalTasks;

          return (
            <div
              key={member.id}
              className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col min-h-[320px]"
            >
              {/* Member Column Header */}
              <div className="p-4 border-b border-slate-100 bg-slate-50/50">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-7 h-7 rounded-lg text-xs flex items-center justify-center font-bold ${member.color.bg} ${member.color.text} border ${member.color.border}`}
                    >
                      {member.initials}
                    </span>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 leading-tight">
                        {member.name}
                      </h3>
                      <p className="text-[11px] text-slate-500 truncate max-w-[140px]">
                        {member.role}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`font-mono text-xs font-semibold tabular-nums px-2 py-0.5 rounded-md ${
                      isComplete
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200/60 text-slate-700'
                    }`}
                  >
                    {completedCount}/{totalTasks}
                  </span>
                </div>

                {/* Mini progress bar */}
                <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden mt-3">
                  <div
                    className={`h-full transition-all duration-300 ${
                      isComplete ? 'bg-emerald-600' : 'bg-slate-700'
                    }`}
                    style={{
                      width: totalTasks > 0 ? `${(completedCount / totalTasks) * 100}%` : '0%',
                    }}
                  />
                </div>
              </div>

              {/* Task list for this member */}
              <div className="p-3 flex-1 flex flex-col gap-2">
                {memberTasks.length > 0 ? (
                  memberTasks.map((task) => (
                    <TaskItem
                      key={task.id}
                      task={task}
                      date={selectedDate}
                      onEdit={handleEdit}
                    />
                  ))
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-4 text-slate-400">
                    <p className="text-xs">No tasks due today</p>
                    <span className="text-[11px] text-slate-400 mt-1">
                      Scheduled for other days
                    </span>
                  </div>
                )}
              </div>

              {/* Member card footer quick action */}
              {totalTasks > 0 && (
                <div className="p-2.5 border-t border-slate-100 bg-slate-50/50 flex justify-between items-center text-xs">
                  <span className="text-[11px] text-slate-500 font-mono tabular-nums">
                    {isComplete ? 'All verified' : `${totalTasks - completedCount} pending`}
                  </span>
                  <button
                    onClick={() => markAllForDate(selectedDate, !isComplete, member.id)}
                    className="text-slate-700 hover:text-slate-900 font-semibold hover:underline cursor-pointer text-[11px]"
                  >
                    {isComplete ? 'Reset' : 'Check All'}
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
