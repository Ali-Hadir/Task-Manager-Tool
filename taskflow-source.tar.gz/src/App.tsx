import React from 'react';
import { TaskProvider, useTasks } from './context/TaskContext';
import { TopNav } from './components/TopNav';
import { DateBar } from './components/DateBar';
import { IndividualView } from './components/IndividualView';
import { TeamBoardView } from './components/TeamBoardView';
import { ReportsView } from './components/ReportsView';
import { TaskManagementView } from './components/TaskManagementView';
import { TaskModal } from './components/TaskModal';

const MainAppContent: React.FC = () => {
  const { viewMode } = useTasks();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900">
      {/* Top Bar with 3-Zone Contract */}
      <TopNav />

      {/* Date Navigation & Daily Metric Bar (displayed on daily checklist & team views) */}
      {(viewMode === 'individual' || viewMode === 'team') && <DateBar />}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {viewMode === 'individual' && <IndividualView />}
        {viewMode === 'team' && <TeamBoardView />}
        {viewMode === 'reports' && <ReportsView />}
        {viewMode === 'manage' && <TaskManagementView />}
      </main>

      {/* Shared Task Creator & Recurrence Editor Modal */}
      <TaskModal />

      {/* Minimal Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">TaskFlow</span>
            <span aria-hidden="true">·</span>
            <span>Minimalist Recurring Task & Team Verification Hub</span>
          </div>
          <div className="flex items-center gap-3">
            <span>Automated Day-by-Day Scheduling</span>
            <span aria-hidden="true">·</span>
            <span>Audit-Ready Reports</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <TaskProvider>
      <MainAppContent />
    </TaskProvider>
  );
}
