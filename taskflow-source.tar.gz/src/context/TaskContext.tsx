import React, { createContext, useContext, useState, useEffect } from 'react';
import { Task, TeamMember, TaskCompletionRecord, ViewMode } from '../types';
import { INITIAL_MEMBERS, INITIAL_TASKS, generateInitialCompletions } from '../data/initialData';
import { formatDateKey, isTaskDueOnDate } from '../utils/dateUtils';

interface TaskContextType {
  tasks: Task[];
  members: TeamMember[];
  completions: Record<string, TaskCompletionRecord>;
  selectedDate: Date;
  setSelectedDate: (date: Date) => void;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  selectedMemberId: string;
  setSelectedMemberId: (id: string) => void;
  toggleTaskCompletion: (taskId: string, date?: Date) => void;
  setTaskCompletion: (taskId: string, date: Date, completed: boolean) => void;
  markAllForDate: (date: Date, completed: boolean, memberIdFilter?: string) => void;
  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => Task;
  updateTask: (task: Task) => void;
  deleteTask: (taskId: string) => void;
  addMember: (member: Omit<TeamMember, 'id'>) => TeamMember;
  resetToDemo: () => void;
  getDueTasksForDate: (date: Date, memberIdFilter?: string) => Task[];
  isTaskCompleted: (taskId: string, date?: Date) => boolean;
  getTaskCompletion: (taskId: string, date?: Date) => TaskCompletionRecord | undefined;
  isTaskModalOpen: boolean;
  setIsTaskModalOpen: (open: boolean) => void;
  editingTask: Task | null;
  setEditingTask: (task: Task | null) => void;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

const STORAGE_KEYS = {
  TASKS: 'taskflow_tasks_v2',
  MEMBERS: 'taskflow_members_v2',
  COMPLETIONS: 'taskflow_completions_v2',
};

export const TaskProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [selectedDate, setSelectedDate] = useState<Date>(() => new Date());
  const [viewMode, setViewMode] = useState<ViewMode>('individual');
  const [selectedMemberId, setSelectedMemberId] = useState<string>('all');
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  // Initialize state with localStorage or defaults
  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TASKS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load tasks', e);
    }
    return INITIAL_TASKS;
  });

  const [members, setMembers] = useState<TeamMember[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load members', e);
    }
    return INITIAL_MEMBERS;
  });

  const [completions, setCompletions] = useState<Record<string, TaskCompletionRecord>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPLETIONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load completions', e);
    }
    return generateInitialCompletions(new Date());
  });

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
    } catch (e) {
      console.error(e);
    }
  }, [tasks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
    } catch (e) {
      console.error(e);
    }
  }, [members]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COMPLETIONS, JSON.stringify(completions));
    } catch (e) {
      console.error(e);
    }
  }, [completions]);

  const getCompletionKey = (taskId: string, date: Date) => {
    return `${formatDateKey(date)}_${taskId}`;
  };

  const isTaskCompleted = (taskId: string, date: Date = selectedDate): boolean => {
    const key = getCompletionKey(taskId, date);
    return Boolean(completions[key]?.completed);
  };

  const getTaskCompletion = (taskId: string, date: Date = selectedDate): TaskCompletionRecord | undefined => {
    const key = getCompletionKey(taskId, date);
    return completions[key];
  };

  const toggleTaskCompletion = (taskId: string, date: Date = selectedDate) => {
    const dateKey = formatDateKey(date);
    const key = `${dateKey}_${taskId}`;
    const current = Boolean(completions[key]?.completed);
    const task = tasks.find((t) => t.id === taskId);

    setCompletions((prev) => {
      const next = { ...prev };
      if (current) {
        // Toggle to uncompleted
        delete next[key];
      } else {
        next[key] = {
          taskId,
          date: dateKey,
          completed: true,
          completedAt: new Date().toISOString(),
          completedBy: task ? task.assigneeId : 'user',
        };
      }
      return next;
    });
  };

  const setTaskCompletion = (taskId: string, date: Date, completed: boolean) => {
    const dateKey = formatDateKey(date);
    const key = `${dateKey}_${taskId}`;
    const task = tasks.find((t) => t.id === taskId);

    setCompletions((prev) => {
      const next = { ...prev };
      if (!completed) {
        delete next[key];
      } else {
        next[key] = {
          taskId,
          date: dateKey,
          completed: true,
          completedAt: new Date().toISOString(),
          completedBy: task ? task.assigneeId : 'user',
        };
      }
      return next;
    });
  };

  const getDueTasksForDate = (date: Date, memberIdFilter?: string): Task[] => {
    return tasks.filter((t) => {
      if (memberIdFilter && memberIdFilter !== 'all' && t.assigneeId !== memberIdFilter) {
        return false;
      }
      return isTaskDueOnDate(t, date);
    });
  };

  const markAllForDate = (date: Date, completed: boolean, memberIdFilter?: string) => {
    const dueTasks = getDueTasksForDate(date, memberIdFilter);
    const dateKey = formatDateKey(date);

    setCompletions((prev) => {
      const next = { ...prev };
      dueTasks.forEach((t) => {
        const key = `${dateKey}_${t.id}`;
        if (completed) {
          next[key] = {
            taskId: t.id,
            date: dateKey,
            completed: true,
            completedAt: new Date().toISOString(),
            completedBy: t.assigneeId,
          };
        } else {
          delete next[key];
        }
      });
      return next;
    });
  };

  const addTask = (taskInput: Omit<Task, 'id' | 'createdAt'>): Task => {
    const newTask: Task = {
      ...taskInput,
      id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setTasks((prev) => [newTask, ...prev]);
    return newTask;
  };

  const updateTask = (updated: Task) => {
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
  };

  const deleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    // Clean up completions
    setCompletions((prev) => {
      const next = { ...prev };
      Object.keys(next).forEach((k) => {
        if (k.endsWith(`_${taskId}`)) {
          delete next[k];
        }
      });
      return next;
    });
  };

  const addMember = (memberInput: Omit<TeamMember, 'id'>): TeamMember => {
    const newMember: TeamMember = {
      ...memberInput,
      id: `member-${Date.now()}`,
    };
    setMembers((prev) => [...prev, newMember]);
    return newMember;
  };

  const resetToDemo = () => {
    localStorage.removeItem(STORAGE_KEYS.TASKS);
    localStorage.removeItem(STORAGE_KEYS.MEMBERS);
    localStorage.removeItem(STORAGE_KEYS.COMPLETIONS);
    setTasks(INITIAL_TASKS);
    setMembers(INITIAL_MEMBERS);
    setCompletions(generateInitialCompletions(new Date()));
    setSelectedDate(new Date());
    setSelectedMemberId('all');
  };

  return (
    <TaskContext.Provider
      value={{
        tasks,
        members,
        completions,
        selectedDate,
        setSelectedDate,
        viewMode,
        setViewMode,
        selectedMemberId,
        setSelectedMemberId,
        toggleTaskCompletion,
        setTaskCompletion,
        markAllForDate,
        addTask,
        updateTask,
        deleteTask,
        addMember,
        resetToDemo,
        getDueTasksForDate,
        isTaskCompleted,
        getTaskCompletion,
        isTaskModalOpen,
        setIsTaskModalOpen,
        editingTask,
        setEditingTask,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};

export function useTasks() {
  const context = useContext(TaskContext);
  if (!context) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
}
